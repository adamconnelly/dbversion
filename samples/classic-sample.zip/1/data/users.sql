insert into users (UserId, UserName, Name, Password, DateOfBirth, Email, Email1)
	values ('93636F91-1759-4A37-B7C0-E7651233B805', 'Administrator', 'Administrator', '721a24eedd64508347a82bebd1e0debf2e5db282', null, 'admin@site.com', 'admin1@site.com');
